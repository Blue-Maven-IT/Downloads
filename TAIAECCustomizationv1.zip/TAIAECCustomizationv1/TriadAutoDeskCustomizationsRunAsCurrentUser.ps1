﻿#AutoCAD Customizer for Triad Associates
#Angela Lacy
#10-JUL-2024
#Download the BlueMavenIT folder
#Run this powershell script as administrator from within the BlueMavenIT folder
#Run this powershell script while logged in as the intended end user - do not run from within the Remote Support profile

#Get Location
$cd = Get-Location

#Copy Fonts to AutoCAD (Currently 97 files)
Copy-Item -Path "$cd\Fonts\*" -Destination "C:\Program Files\Autodesk\AutoCAD 2024\Fonts" -Recurse -ErrorAction SilentlyContinue

#Copy Plotters to AutoCAD
Copy-Item -Path "$cd\Plotters\*" -Destination "$env:APPDATA\Autodesk\AutoCAD 2024\R24.3\enu\Plotters" -Recurse -ErrorAction SilentlyContinue

#Copy Plotters to Civil 3D
Copy-Item -Path "$cd\Plotters\*" -Destination "$env:APPDATA\Autodesk\C3D 2024\enu\Plotters" -Recurse -ErrorAction SilentlyContinue

#Copy Plotters to #Map 3D
Copy-Item -Path "$cd\Plotters\*" -Destination "$env:APPDATA\Autodesk\Autodesk AutoCAD Map 3D 2024\R24.3\enu\Plotters" -Recurse -ErrorAction SilentlyContinue

#Copy Support to AutoCAD
Copy-Item -Path "$cd\Support\*" -Destination "$env:APPDATA\Autodesk\AutoCAD 2024\R24.3\enu\Support" -Recurse -Force -ErrorAction SilentlyContinue

#Copy Support to Civil 3D
Copy-Item -Path "$cd\Support\*" -Destination "$env:APPDATA\Autodesk\C3D 2024\enu\Support" -Recurse -Force -ErrorAction SilentlyContinue

#Copy Support to Map 3D
Copy-Item -Path "$cd\Support\*" -Destination "$env:APPDATA\Autodesk\Autodesk AutoCAD Map 3D 2024\R24.3\enu\Support" -Recurse -Force -ErrorAction SilentlyContinue